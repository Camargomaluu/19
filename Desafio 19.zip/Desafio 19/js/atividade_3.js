var senhaCorreta = "236728";  

    function verificarSenha() {
      var senhaDigitada = prompt("Digite a senha:");

      while (senhaDigitada !== senhaCorreta) {
        alert("Senha incorreta! Tente novamente.");
        senhaDigitada = prompt("Digite a senha:");
      }

      alert("Senha correta! Acesso permitido.");
    }

    verificarSenha();
